import numpy as np
import matplotlib.pyplot as plt
import math
import random
import xlrd
import xlwt
import csv
import pandas as pd
import weka.core.jvm as jvm
import weka.core.packages as packages
from weka.classifiers import Classifier
from weka.core.converters import Loader
from weka.core.dataset import Instances
from weka.classifiers import Classifier
import weka.core.serialization as serialization
from weka.classifiers import Classifier
import traceback
import os
from weka.classifiers import Classifier
import scipy.stats.stats as st
import sys
import sys, getopt
import openpyxl    
import arff
import time

codepath=os.getcwd()
# Setting general parameters
datafilename='AAP2' # Name of the data file
rawdir=codepath+'\\Raw\\' # Folder where you place the data
prodir=codepath+'\\Results\\' +datafilename+'\\'# Folder where you wish to place the processed data
data_AAraw = open(codepath+'\\raw\\AAindex_raw.txt') # Folder where you place the raw AAindex data, the default is the path where you place this code
#auto-selection of computing mode, following the name of the datafile

localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Programme started')

# PART 1 AAindex loading and standardisation
#Load AA index,
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   AAinedx loading started ') # AA index loaded at this step was unmodified

preAAmatrix=[]
AAmatrix = []
element = []

def norm(x):# For AAindex standardisation
    use =[]
    for i in range(len(x)):
        x[i]=float(x[i])
    arr_mean = np.mean(x)
    arr_std = np.std(x,ddof=0)
    for k in range(len(x)):
        ele = (x[k]-arr_mean)/arr_std
        use.append(ele)
    return use

trig=0
for line in data_AAraw.readlines(): #read numerical values from AAindex rawfile
    if "A/L" in line:
        trig = 1
        continue
    if trig ==1:  
        for i in range(len(line)):
            if line[i]!=' ':
                element+=line[i]
                if i<len(line)-1:
                    if line[i+1]==' 'or line[i+1]=='\n':
                       element2=''.join(element)
                       preAAmatrix.append(element2)
                       element = []                         
        trig = trig+1
        continue
    if trig ==2:
        element = []
        for i in range(len(line)):
            if line[i]!=' ':
                element+=line[i] 
                if i<len(line)-1:
                    if line[i+1]==' 'or line[i+1]=='\n':
                       element2=''.join(element)
                       preAAmatrix.append(element2)
                       element = []                         
        trig = 0
    if preAAmatrix!=[]:
        AAmatrix.append(preAAmatrix)  
    preAAmatrix = []
    element = []
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Raw AAindex loading done')
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   AAindex standardisation started')
def cleanNA(x): # To remove properties containing null value
    new = []
    nl = []
    for i in range(len(x)):
        linex = x[i]
        for j in range(len(linex)):
            if linex[j]!='NA':
                ele = float(linex[j])
                nl.append(ele)
        if len(nl)==20:
            new.append(nl)
        nl = []
    return new
AAmatrix=cleanNA(AAmatrix)
for i in range(len(AAmatrix)):
    AAmatrix[i]=norm(AAmatrix[i])
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   AAindex standardisation done')

# PART 2 Sequence encoding
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Sequence encoding started')
acalpbt =['A','R','N','D','C','Q','E','G','H','I','L','K','M','F','P','S','T','W','Y','V']
data = open(rawdir+datafilename+'.txt')
seqtype =[]
seqcont =[]
# Loading the sequence information from relevant FAST files
for line in data.readlines():
    if ">" in line:
        seqtype.append(line[len(line)-2])
    else:
        if line[len(line)-1]!='\n':
            line.strip()
            seqcont.append(line)
        else: 
            line.strip()
            seqcont.append(line[0:len(line)-1])
        
if len(seqtype)==len(seqcont):
    localtime = time.asctime( time.localtime(time.time()) )
    print (str(localtime)+'   File check done')
    num = len(seqtype)
# Store positive and negative samples separately
t=[]
f=[]
cot=0
cof=0
for p in range(num):
    if seqtype[p]=='1':
        t.append(seqcont[p])
        cot=cot+1
    else:
        f.append(seqcont[p])
        cof=cof+1

list_newseqA=t
list_newseqB=f
list_newseqC=[]
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Sequences loading done') 
AAinline = []
AAinlineZ = []
AAinlineJ = []
A=[]
m=[]
mm=[]
jj=[]
zz=[]
jx=[]
z=[]
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Sequences encoding started') 
# Direct encoding of sequences using standardised AAindex
for i in range(len(AAmatrix)):
    AAline = AAmatrix[i]
    for j in range(len(list_newseqA)):
        hseq = list_newseqA[j]
        for k in range(len(hseq)):
            hre = hseq[k]
            for p in range(len(acalpbt)):
                if hre == acalpbt[p]:
                   AAinline.append(AAline[p])
        z.append(AAinline)
        AAinline = []
    zz.append(z)
    z=[]
    
    AAinline = []
    for j in range(len(list_newseqB)):
        hseq = list_newseqB[j]
        for k in range(len(hseq)):
            hre = hseq[k]
            for p in range(len(acalpbt)):
                if hre == acalpbt[p]:
                   AAinline.append(AAline[p])
        jx.append(AAinline)
        AAinline = []
    jj.append(jx)
    jx=[]
    
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Primitive encoding done')

localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Feature extraction started')
def corre(x,n): #Auto-correlation function
    q=np.correlate(x, x, mode = 'full')
    return q[n]/(len(x)-n)         
#10D descriptor
def AAcal(seqcont,va):
    v=[]
    for i in range(len(seqcont)):
        vtar=seqcont[i]
        vtarv=[]
        vtar7=0
        vtar8=0
        vtar9=0
        s = pd.Series(vtar)    
        vtar3=np.mean(vtar)  # These 4 dimensions are relevant statistical terms
        vtar4=st.kurtosis(vtar)
        vtar5=np.std(vtar,ddof=0)
        vtar6=st.skew(vtar)
        for p in range(len(vtar)): # These 3 dimensions are inspired by PAFIG algorithm
            vtar7=vtar[p]**2+vtar7
            if vtar[p]>va:
                vtar8=vtar[p]**2+vtar8
            else:
                vtar9=vtar[p]**2+vtar9
        vcf1=[]
        vcf2=[]
        for j in range(len(vtar)-1):
            vcf1.append((vtar[j]-vtar[j+1])**2)
        for k in range(len(vtar)-2):
            vcf2.append((vtar[k]-vtar[k+2])**2)
        vtar10=np.mean(vcf1)
        vtar11=np.std(vcf1,ddof=0)
        vtar12=np.mean(vcf2)
        vtar13=np.std(vcf2,ddof=0)
        vtarv.append(vtar3)
        vtarv.append(vtar4)
        vtarv.append(vtar5)
        vtarv.append(vtar6)
        vtarv.append(vtar7/len(vtar))
        vtarv.append(vtar8/len(vtar))
        vtarv.append(vtar9/len(vtar))
        vtarv.append(vtar10)
        vtarv.append(vtar11)
        vtarv.append(vtar12)
        vtarv.append(vtar13)
        v.append(vtarv)
    return v

# Store relevant features
bigZ=[]
for i in range(len(zz)):
    zline = AAcal(zz[i],0)
    bigZ.append(zline)
bigJ=[]
for i in range(len(jj)):
    jline = AAcal(jj[i],0)
    bigJ.append(jline)
big=[]
for i in range(len(jj)):
    bigm = bigZ[i]+bigJ[i]
    big.append(bigm)
    
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Feature extraction done')

def addlable(W1): # function for labelling input data
   for i in range(len(W1)):
       lineprc = W1[i]
       if i<cot:
           lineprc.append('NO')
       if i>=cot:
           lineprc.append('YES')
    
def addID(W1): # function for adding ID to input data
   for i in range(len(W1)):
       lineprc = W1[i]
       lineprc.insert(0,i)
                   
for i in range(len(big)): # label the input data
    addlable(big[i])

for i in range(len(big)):# Add ID to the input data
    addID(big[i])

def xlsx_to_csv_pd(a,b):
    data_xls = pd.read_excel(a, index_col=0)
    data_xls.to_csv(b, encoding='utf-8')
    
atb=[]
atbID=('ID','REAL')
atb.append(atbID)
for i in range(11):
    atbf=('f'+str(i+1),'REAL')
    atb.append(atbf)
atbclss=('class', ['NO', 'YES'])
atb.append(atbclss)

localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Create essential folders')

npathdata=prodir+'Data\\'
npathmetric=prodir+'Metrics\\'

npathlevel1=npathdata+'Level1\\'
npathlevel2=npathdata+'Level2\\'
arfflevel1=npathlevel1+'Arff\\'
arfflevel2=npathlevel2+'Arff\\'
datalevel1=npathlevel1+'Data\\'
datalevel2=npathlevel2+'Data\\'
modellevel1=npathlevel1+'Model\\'
modellevel2=npathlevel2+'Model\\'
mpmetrics=npathmetric+'531 Metrics\\'
lrmetrics=npathmetric+'Learning metrics\\'
mplearn=npathmetric+'Learning\\'


os.makedirs(npathdata, exist_ok=True)
os.makedirs(npathlevel1, exist_ok=True)
os.makedirs(npathlevel2, exist_ok=True)
os.makedirs(arfflevel1, exist_ok=True)
os.makedirs(arfflevel2, exist_ok=True)
os.makedirs(datalevel1, exist_ok=True)
os.makedirs(datalevel2, exist_ok=True)
os.makedirs(modellevel1, exist_ok=True)
os.makedirs(modellevel2, exist_ok=True)
os.makedirs(npathmetric, exist_ok=True)
os.makedirs(mpmetrics, exist_ok=True)
os.makedirs(mplearn, exist_ok=True)
os.makedirs(lrmetrics, exist_ok=True)

localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   ARFF file production started')

for i in range(len(big)):
    f=open(arfflevel1+'arff'+str(i+1)+'.arff','w')
    W1 = big[i]
    index = len(W1)
    obj = {
        'description': u'',
        'relation': datafilename+'feature',
        'attributes': atb,
        'data':W1,
    }
    f.write(arff.dumps(obj))
    f.close()
    
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   ARFF file production done')   
#Start JVM for employing WEKA
jvm.start(packages=True)
Total=[]
cxx=[]
cyy=[]
from weka.plot.classifiers import generate_thresholdcurve_data
from weka.plot.classifiers import get_thresholdcurve_data
from weka.filters import Filter
from weka.classifiers import FilteredClassifier
import weka.core.serialization as serialization
from weka.classifiers import Evaluation
from weka.core.classes import Random
from weka.classifiers import PredictionOutput

for i in range(531):
    nasavesumary='sumary'+str(i+1)
    nasavebuffer='buffer'+str(i+1)
    nasavedetail='detail'+str(i+1)
    savesumary=open(datalevel1+nasavesumary+'.txt','w')
    savebuffer=open(datalevel1+nasavebuffer+'.txt','w')
    savedetail=open(datalevel1+nasavedetail+'.txt','w')
    loader = Loader(classname="weka.core.converters.ArffLoader")
    data = loader.load_file(arfflevel1+'arff'+str(i+1)+'.arff')
    data.class_is_last()
 
    remove = Filter(classname="weka.filters.unsupervised.attribute.Remove", options=["-R", "1"])
    cls = Classifier(classname="weka.classifiers.trees.RandomForest")

    fc = FilteredClassifier()
    fc.filter = remove
    fc.classifier = cls
    fc.build_classifier(data)
    classifier = fc  # previously built classifier
    serialization.write(modellevel1 +'P'+str(i+1)+'.model', classifier)
    
    pout = PredictionOutput(classname="weka.classifiers.evaluation.output.prediction.PlainText",options=["-p","1"])
    evl = Evaluation(data)
    evl.crossvalidate_model(fc, data, 10, Random(1), pout)
    cdata=generate_thresholdcurve_data(evl,0)
    str(cdata)
    cdx,cdy= get_thresholdcurve_data(cdata, "False Positive Rate", "True Positive Rate")
    cxx.append(cdx)
    cyy.append(cdy)
    Total.append(evl.percent_correct)
    localtime = time.asctime( time.localtime(time.time()) )
    print(str(localtime)+'    WEKA now processing'+'property NO.'+str(i+1)+' out of 531')
    
    savesumary.writelines(evl.summary())
    savesumary.close()
    savebuffer.writelines(pout.buffer_content())
    savebuffer.close()
    savedetail.writelines(evl.class_details())
    savedetail.close()
    
jvm.stop()
def savetu(W1,ad):
    datasave = openpyxl.Workbook()  # 新建一个工作簿
    datasave.create_sheet('Sheet1') # 在工作簿中新建一个表格
    table = datasave.active
    index=len(W1)
    for j in range(index):
        each = W1[j]
        for k in range(len(each)):
            table.cell(k+1, j+1, each[k])
    datasave.save(datalevel1+ad)
    datasave.close()# 保存工作簿

savetu(cxx,datafilename+'FP.xls')
savetu(cyy,datafilename+'TP.xls')
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   WEKA work done')
#Write the merics of all properties
data_dirx= datalevel1#Folder storing all training detail
def readSP(x): #read specificity
    data=open(x)
    for line in data.readlines():
        if line[96:97]=='O':
            ppp=line[17:24]      
    return ppp

def readSE(x):#read sensitivity
    data=open(x)
    for line in data.readlines():
        if line[96:97]=='E':
            ppp=line[17:24]      
    return ppp

def readMCC(x):#read MCC
    data=open(x)
    for line in data.readlines():
        if line[0]=='W':
            ppp=line[66:71]      
    return ppp

def readAUC(x):
    data=open(x)
    for line in data.readlines():
        if line[0]=='W':
            ppp=line[75:80]      
    return ppp

merics=[]
for i in range(531):
    mericline=[]
    mericfile=data_dirx+'detail'+str(i+1)+'.txt'
    mericline.append(readAUC(mericfile))
    mericline.append(readMCC(mericfile))
    mericline.append(readSE(mericfile))
    mericline.append(readSP(mericfile))
    merics.append(mericline)
               
index = len(merics)  # 获取需要写入数据的行数
workbook = xlwt.Workbook()  # 新建一个工作簿
sheet = workbook.add_sheet('sheet_name')  # 在工作簿中新建一个表格
linehead=['No.','AUC','ACC','MCC','SE','SP']
for j in range(0, len(linehead)):
    sheet.write(0, j, linehead[j])
for i in range(0, index):
    wrtmericline=merics[i]
    sheet.write(i+1,0,i+1)
    sheet.write(i+1,1,wrtmericline[0])
    sheet.write(i+1,3,wrtmericline[1])
    sheet.write(i+1,4,wrtmericline[2])
    sheet.write(i+1,5,wrtmericline[3])
    sheet.write(i+1,2,Total[i]/100) 
filename = 'Merics'+'.xls'
workbook.save(mpmetrics +filename)  # 保存工作簿

localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   531D 1/0 vector production started')
#Produce 531 1/0 vectors based on previous training outcome (10-cross validation)
data_dir2= datalevel1
newID=np.arange(0,len(seqcont)+20,1)
allbi=[]

for j in range(531):
    linebi=[]
    typ=[]
    ID=[]
    data=open(data_dir2+'buffer'+str(j+1)+'.txt')
    for line in data.readlines():
        if line[30]=='d':
            continue
        srt=0
        for i in range(len(line)):
            if line[i]=='(' and line[i+1]!='I':
                srt=i
            if line[i]==')'and line[i-1]!='D':
                stp=i
        prv=float(line[38:srt-1])
        if line[30]=='S':
            typ.append(1)
        if line[30]=='O':
            typ.append(0)
        if srt>0:
            ID.append(int(line[srt+1:stp]))
    for k in range(len(newID)):
        for p in range(len(ID)):
            if newID[k]==ID[p]:
                linebi.append(typ[p])
    allbi.append(linebi)
    localtime = time.asctime( time.localtime(time.time()) )
    print(str(localtime)+'   531D now processing the dimension of '+str(j+1))
                
def nbgenea(n):#function for producing the headline in later sheet
    qq=[]
    for i in range(n):
        fname='f'+str(i+1)
        qq.append(fname)
    qq.append('class')
    return qq

def nbgeneb(n):#function for producing the headline in later sheet, which shall be processed by MRMD2.0
    qq=[]
    ko=[]
    for i in range(n):
        fname='f'+str(i+1)
        qq.append(fname)
    ko.append('class')
    ko=ko+qq
    return ko

localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   531D vectors production done')
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Records production started')
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Production of CSV for MRMD2.0 started')
#Produce the sheets containing all features, normal format 
W1 = allbi
W2 = allbi
W3 = allbi      
index = len(W1)
classw1=[]
nbtitle = nbgenea(531)
datasave = openpyxl.Workbook()  
datasave.create_sheet('Sheet1')
table = datasave.active
saveid=[]
for i in range(len(seqcont)):
    saveid.append(i+1)
for i in range(len(nbtitle)):
    table.cell(1, i+1, nbtitle[i])
for j in range(index):
    each = W1[j]
    for k in range(len(each)):
        table.cell(k+2, j+1, each[k])
        if k<cot:
            table.cell(k+2, index+1, 'NO')
            #classw1.append('NO')
        if k>=cot:
            table.cell(k+2, index+1, 'YES')
            #classw1.append('YES')
filenamex = 'all_features_normal'+'.xls'
datasave.save(data_dir2+filenamex)
datasave.close()

for k in range(len(seqcont)):
    if k<cot:
        classw1.append('NO')
    if k>=cot:
        classw1.append('YES')
savearr=[]
savearr.append(saveid)
for i in range(531):
    savearr.append(W1[i])
savearr.append(classw1)
np.save(npathlevel1+'big.npy',savearr)

#Produce the sheets containing all features, MRMD2.0 processable format
index = len(W3)  
nbtitlex = nbgeneb(531)
datasave2z = openpyxl.Workbook()  
datasave2z.create_sheet('Sheet1') 
table = datasave2z.active
for i in range(len(nbtitle)):
    table.cell(1, i+1, nbtitlex[i])
for j in range(index):
    each = W3[j]
    for k in range(len(each)):
        table.cell(k+2, j+2, each[k])
        if k<cot:
            table.cell(k+2, 1, 0)
        if k>=cot:
            table.cell(k+2, 1, 1) 
filenamex = 'all_features_for_MRMD'+'.xls'
filenamex2 = 'all_features_for_MRMD'+'.csv'
datasave2z.save(data_dir2+filenamex)
datasave2z.close()
xlsx_to_csv_pd(data_dir2+filenamex,data_dir2+filenamex2)
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   CSV for MRMD2.0 done')

savename=[]
savename.append(datafilename)
os.remove(codepath+'\\prebig.npy')
np.save(codepath+'\\prebig.npy',savename)
print('Now please run MRMD2.0ranking.py')

