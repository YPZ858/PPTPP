import numpy as np
import matplotlib.pyplot as plt
import math
import random
import xlrd
import xlwt
import csv
import pandas as pd
import weka.core.jvm as jvm
import weka.core.packages as packages
from weka.classifiers import Classifier
from weka.core.converters import Loader
from weka.core.dataset import Instances
from weka.classifiers import Classifier
import weka.core.serialization as serialization
from weka.classifiers import Classifier
import traceback
import os
from weka.classifiers import Classifier
import openpyxl
import shutil
from openpyxl import load_workbook

codepath='C:\\Users\\heartunderblade\\Documents\\YPZ\\Codes'
datafilename='QSP'
data_dir=codepath+'\\processed2\\'+datafilename+'BF\\'
logname='201911230419'
xlsname='all_features_normal'
data=open(data_dir+logname+'.log')
rallf=[]
for line in data.readlines():
    fline=[]
    if len(line)<27:
        continue
    if line[27]!='f':
        continue
    for i in range(len(line)):
        if line[i]=='f' and line[i-1]==' ' :
            strn = i
        if line[i]==':' and line[i-1]==' ' :
            stpn = i
    rallf.append(line[strn+1:stpn])
allf=rallf[0:531]
print('MRMD2.0 log loading done')
def getcol(x):
    col = pd.read_excel(data_dir+xlsname+'.xls', usecols=[x])
    col_list = col.values.tolist()
    result = []
    for col_listx in col_list:
        result.append(col_listx[0])
    return result

def nbgenea(n):
    qq=[]
    for i in range(n):
        fname='f'+str(i+1)
        qq.append(fname)
    qq.append('class')
    return qq
def xlsx_to_csv_pd(a,b):
    data_xls = pd.read_excel(a, index_col=0)
    data_xls.to_csv(b, encoding='utf-8')  
clos=[]
classname=getcol(531)
SF_dir=codepath
datasave = openpyxl.Workbook()  # 新建一个工作簿
datasave.create_sheet('Sheet1') # 在工作簿中新建一个表格
table = datasave.active
table.cell(1, 1, 'ID')

os.makedirs(codepath+'\\processed2\\'+datafilename+'SF\\', exist_ok=True)
#xlsx_to_csv_pd(SF_dir+filenamex+'.xls',SF_dir+filenamex+str(i)+'.csv')
SF_dir=codepath+'\\processed2\\'+datafilename+'SF\\'
nbtitle=nbgenea(531)
for i in range(531):
    content=getcol(int(allf[i])-1)
    for j in range(len(content)):
        table.cell(j+2, i+2, content[j])
    print(i)
for k in range(len(classname)):
    table.cell(k+2, 531+2, classname[k])
    table.cell(k+2, 1, k+1)
for z in range(len(nbtitle)):
    table.cell(1, z+2, nbtitle[z])
    filenamex1='feature'
datasave.save(SF_dir+filenamex1+'all.xls')
datasave.close()# 保存工作簿
filenamex1='feature'
print('CSV to ARFF conversion started')

for i in range(531):
    filenamex='feature 0 to '
    newname=filenamex+str(i)+'.xlsx'
    shutil.copy(SF_dir+filenamex1+'all.xls',SF_dir+newname)
    if i==530:
        break
    ws = load_workbook(SF_dir+newname)
    wb=ws.active
    wb.delete_cols(3+i,530-i)
    ws.save(SF_dir+newname)
    xlsx_to_csv_pd(SF_dir+newname,SF_dir+filenamex+str(i)+'.csv')

for mm in range(531):
    NfileIn =SF_dir+filenamex+str(mm)+'.csv' #csv file name or absolute path to be open.
    NfileOut= SF_dir+filenamex+str(mm)+'ARFF.arff' #name as how you'll save your arff file.
    relation = "convertion" #how you'll like to call your relation as.

    fileIn = open(NfileIn);
    fileOut = open(NfileOut,"w")
    relation = "conversion"

    f = open(NfileIn, 'r')
    reader = csv.reader(f)
    datapoints = list(reader)
    attributes = datapoints [0]

    lastPos = fileIn.tell()

    fileOut.write("%\n% Comments go after a '%' sign.\n%\n")
    fileOut.write("%\n% Relation: " + relation +"\n%\n%\n")
    fileOut.write("% Attributes: " + str(len(attributes)) + " "*5 
	    + "Instances: " + str(len(datapoints)-1) + "\n%\n%\n\n")
    fileOut.write("@relation " + relation + "\n\n")
    count=1
    for k in range(len(fileIn.readline().strip().split(','))-1):
	    fileOut.write("@attribute" + " '" + attributes[k] 
		    + "'" + " numeric\n")
	    count+=1
	
    fileOut.write("@attribute"+ " '" + str(attributes[len(attributes)-1])+"' "
                  +"{'no'"+"'yes'}\n")	
    fileOut.write("\n@data\n");

    fileIn.seek(lastPos)

    tempStr = []

    for line in fileIn:
        if line[0]!='I':
            for i in range(len(line.strip().split(','))):
                if i==len(line.strip().split(','))-1:
                    tempStr.append("'"+(line.strip().split(',')[i]).lower()+"'")
                else:
                    tempStr.append(line.strip().split(',')[i])
            fileOut.write(','.join(tempStr)+"\n")
        tempStr= []
        

    fileOut.close()
jvm.start(packages=True)
print('Optimised feature learning started') 
print('WEKA started') 
Total=[]
for i in range(531):
    nasavesumary='sumary'+str(i)
    nasavebuffer='buffer'+str(i)
    nasavedetail='detail'+str(i)
    savesumary=open(SF_dir+nasavesumary+'.txt','w')
    savebuffer=open(SF_dir+nasavebuffer+'.txt','w')
    savedetail=open(SF_dir+nasavedetail+'.txt','w')
    filename2 = filenamex+str(i)+'ARFF'+'.arff'
    loader = Loader(classname="weka.core.converters.ArffLoader")
    data = loader.load_file(SF_dir+filenamex+str(i)+'ARFF.arff')
    data.class_is_last()

    from weka.filters import Filter
    remove = Filter(classname="weka.filters.unsupervised.attribute.Remove", options=["-R", "1"])
    cls = Classifier(classname="weka.classifiers.trees.RandomForest")

    from weka.classifiers import FilteredClassifier
    fc = FilteredClassifier()
    fc.filter = remove
    fc.classifier = cls

    fc.build_classifier(data)
    import weka.core.serialization as serialization
    classifier = fc  # previously built classifier
    serialization.write(SF_dir +'P'+str(i)+'.model', classifier)

    from weka.classifiers import Evaluation
    from weka.core.classes import Random
    from weka.classifiers import PredictionOutput
    pout = PredictionOutput(classname="weka.classifiers.evaluation.output.prediction.PlainText",options=["-p","1"])
    evl = Evaluation(data)
    evl.crossvalidate_model(fc, data, 10, Random(1), pout)
    print('WEKA now processing'+'NO.'+str(i+1))
    Total.append(evl.percent_correct)
    
    savesumary.writelines(evl.summary())
    savesumary.close()
    savebuffer.writelines(pout.buffer_content())
    savebuffer.close()
    savedetail.writelines(evl.class_details())
    savedetail.close()
    
def readSP(x):
    data=open(x)
    for line in data.readlines():
        if line[96:97]=='o':
            ppp=line[17:24]      
    return ppp

def readSE(x):
    data=open(x)
    for line in data.readlines():
        if line[96:97]=='e':
            ppp=line[17:24]      
    return ppp

def readMCC(x):
    data=open(x)
    for line in data.readlines():
        if line[0]=='W':
            ppp=line[66:71]      
    return ppp

def readAUC(x):
    data=open(x)
    for line in data.readlines():
        if line[0]=='W':
            ppp=line[75:80]      
    return ppp

merics=[]
AUC=[]
for i in range(531):
    mericline=[]
    mericfile=SF_dir+'detail'+str(i)+'.txt'
    mericline.append(readAUC(mericfile))
    AUC.append(readAUC(mericfile))
    mericline.append(readMCC(mericfile))
    mericline.append(readSE(mericfile))
    mericline.append(readSP(mericfile))
    merics.append(mericline)

maxaucvalue=AUC[0]
maxid=0
for i in range(len(AUC)):
    if AUC[i]>maxaucvalue:
        maxaucvalue= AUC[i]
        maxid=i
        
maxid=maxid+1           
index = len(merics)  # 获取需要写入数据的行数
workbook = xlwt.Workbook()  # 新建一个工作簿
sheet = workbook.add_sheet('sheet_name')  # 在工作簿中新建一个表格
linehead=['No.','AUC','ACC','MCC','SE','SP']
for j in range(0, len(linehead)):
    sheet.write(0, j, linehead[j])
for i in range(0, index):
    wrtmericline=merics[i]
    sheet.write(i+1,0,i+1)
    sheet.write(i+1,1,wrtmericline[0])
    sheet.write(i+1,3,wrtmericline[1])
    sheet.write(i+1,4,wrtmericline[2])
    sheet.write(i+1,5,wrtmericline[3])
    sheet.write(i+1,2,Total[i]/100) 
filename = 'Merics'+'.xls'
workbook.save(data_dir +filename)  # 保存工作簿

selectedp=allf[0:maxid]
index = len(selectedp)  # 获取需要写入数据的行数
workbook = xlwt.Workbook()  # 新建一个工作簿
sheet = workbook.add_sheet('sheet_name')  # 在工作簿中新建一个表格
linehead=['No.']
for j in range(0, len(linehead)):
    sheet.write(0, j, linehead[j])
for i in range(0, index):
    sheet.write(i+1,0,selectedp[i])   
filename = 'Selected properties'+datafilename+'.xls'
workbook.save(data_dir +filename) 

print('best AUC: '+maxaucvalue)
print('No. of dimensions: '+str(maxid))
print("done")
    
