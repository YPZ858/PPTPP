import numpy as np
import matplotlib.pyplot as plt
import math
import random
import xlrd
import xlwt
import csv
import pandas as pd
import weka.core.jvm as jvm
import weka.core.packages as packages
from weka.classifiers import Classifier
from weka.core.converters import Loader
from weka.core.dataset import Instances
from weka.classifiers import Classifier
import weka.core.serialization as serialization
from weka.classifiers import Classifier
import traceback
import os
from weka.classifiers import Classifier
import scipy.stats.stats as st
import sys
import sys, getopt
import openpyxl    
import arff
import time

jvm.start(packages=True)
codepath=os.getcwd()

datafilename=str(np.load(codepath+'\\prebig.npy'))[2:-2]
rawdir=codepath+'\\Raw\\' # Folder where you place the data
prodir=codepath+'\\Results\\' +datafilename+'\\'# Folder where you wish to place the processed data
npathdata=prodir+'Data\\'
npathmetric=prodir+'Metrics\\'


npathlevel1=npathdata+'Level1\\'
npathlevel2=npathdata+'Level2\\'
arfflevel1=npathlevel1+'Arff\\'
arfflevel2=npathlevel2+'Arff\\'
datalevel1=npathlevel1+'Data\\'
datalevel2=npathlevel2+'Data\\'
modellevel1=npathlevel1+'Model\\'
modellevel2=npathlevel2+'Model\\'
mpmetrics=npathmetric+'531 Metrics\\'
mplearn=npathmetric+'Learning\\'

content=np.load(npathlevel1+'big.npy')
names=np.load(npathdata+'prebigx.npy')
logname=str(names)
data=open(logname)
rallf=[]
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Learning programme started')  
for line in data.readlines():
    fline=[]
    if len(line)<27:
        continue
    if line[27]!='f':
        continue
    for i in range(len(line)):
        if line[i]=='f' and line[i-1]==' ' :
            strn = i
        if line[i]==':' and line[i-1]==' ' :
            stpn = i
    rallf.append(line[strn+1:stpn])
allf=rallf[0:531]

big=[]
big.append(content[0])
for i in range(len(allf)):
    big.append(content[int(allf[i])])
big.append(content[532])
W1=np.transpose(big)
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Data produced during training loaded')  
def atb(x):
    atbq=[]
    atbID=('ID','REAL')
    atbq.append(atbID)
    for i in range(x):
        atbf=('f'+str(i+1),'REAL')
        atbq.append(atbf)
    atbclss=('class', ['NO', 'YES'])
    atbq.append(atbclss)
    return atbq
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   ARFF file production started')  
for i in range(531):
    f=open(arfflevel2+'arff'+str(531-i)+'.arff','w')
    if i>0:
        W1=np.delete(W1,532-i,axis=1)
    obj = {
        'description': u'',
        'relation': datafilename+'feature',
        'attributes': atb(531-i),
        'data':W1,
    }
    f.write(arff.dumps(obj))
    f.close()
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   ARFF file production done')
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   WEKA work started')  
from weka.plot.classifiers import generate_thresholdcurve_data
from weka.plot.classifiers import get_thresholdcurve_data
Total=[]
cxx=[]
cyy=[]
for i in range(531):
    nasavesumary='sumary'+str(i+1)
    nasavebuffer='buffer'+str(i+1)
    nasavedetail='detail'+str(i+1)
    savesumary=open(datalevel2+nasavesumary+'.txt','w')
    savebuffer=open(datalevel2+nasavebuffer+'.txt','w')
    savedetail=open(datalevel2+nasavedetail+'.txt','w')
    loader = Loader(classname="weka.core.converters.ArffLoader")
    data = loader.load_file(arfflevel2+'arff'+str(i+1)+'.arff')
    data.class_is_last()

    from weka.filters import Filter
    remove = Filter(classname="weka.filters.unsupervised.attribute.Remove", options=["-R", "1"])
    cls = Classifier(classname="weka.classifiers.trees.RandomForest")

    from weka.classifiers import FilteredClassifier
    fc = FilteredClassifier()
    fc.filter = remove
    fc.classifier = cls

    fc.build_classifier(data)
    import weka.core.serialization as serialization
    classifier = fc  # previously built classifier
    serialization.write(modellevel2 +'P'+str(i+1)+'.model', classifier)

    from weka.classifiers import Evaluation
    from weka.core.classes import Random
    from weka.classifiers import PredictionOutput
    pout = PredictionOutput(classname="weka.classifiers.evaluation.output.prediction.PlainText",options=["-p","1"])
    evl = Evaluation(data)
    evl.crossvalidate_model(fc, data, 10, Random(1), pout)
    cdata=generate_thresholdcurve_data(evl,0)
    str(cdata)
    cdx,cdy= get_thresholdcurve_data(cdata, "False Positive Rate", "True Positive Rate")
    cxx.append(cdx)
    cyy.append(cdy)
    Total.append(evl.percent_correct)
    localtime = time.asctime( time.localtime(time.time()) )

    print('WEKA now processing'+'NO.'+str(i+1))
    Total.append(evl.percent_correct)
    
    savesumary.writelines(evl.summary())
    savesumary.close()
    savebuffer.writelines(pout.buffer_content())
    savebuffer.close()
    savedetail.writelines(evl.class_details())
    savedetail.close()
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   WEKA work done')

jvm.stop()
def savetu(W1,ad):
    datasave = openpyxl.Workbook()  # 新建一个工作簿
    datasave.create_sheet('Sheet1') # 在工作簿中新建一个表格
    table = datasave.active
    index=len(W1)
    for j in range(index):
        each = W1[j]
        for k in range(len(each)):
            table.cell(k+1, j+1, each[k])
    datasave.save(datalevel2+ad)
    datasave.close()# 保存工作簿

savetu(cxx,datafilename+'FP.xls')
savetu(cyy,datafilename+'TP.xls')

localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   WEKA work done')
def readSP(x):
    data=open(x)
    for line in data.readlines():
        if line[96:97]=='O':
            ppp=line[17:24]      
    return ppp

def readSE(x):
    data=open(x)
    for line in data.readlines():
        if line[96:97]=='E':
            ppp=line[17:24]      
    return ppp

def readMCC(x):
    data=open(x)
    for line in data.readlines():
        if line[0]=='W':
            ppp=line[66:71]      
    return ppp

def readAUC(x):
    data=open(x)
    for line in data.readlines():
        if line[0]=='W':
            ppp=line[75:80]      
    return ppp
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Records production started')  
lrmetrics=npathmetric+'Learning metrics\\'
merics=[]
AUC=[]
for i in range(531):
    mericline=[]
    mericfile=datalevel2+'detail'+str(i+1)+'.txt'
    mericline.append(readAUC(mericfile))
    AUC.append(readAUC(mericfile))
    mericline.append(readMCC(mericfile))
    mericline.append(readSE(mericfile))
    mericline.append(readSP(mericfile))
    merics.append(mericline)

maxaucvalue=AUC[0]
maxid=0
for i in range(len(AUC)):
    if AUC[i]>maxaucvalue:
        maxaucvalue= AUC[i]
        maxid=i
        
maxid=maxid+1           
index = len(merics)  # 获取需要写入数据的行数
workbook = xlwt.Workbook()  # 新建一个工作簿
sheet = workbook.add_sheet('sheet_name')  # 在工作簿中新建一个表格
linehead=['No.','AUC','ACC','MCC','SE','SP']
for j in range(0, len(linehead)):
    sheet.write(0, j, linehead[j])
for i in range(0, index):
    wrtmericline=merics[i]
    sheet.write(i+1,0,i+1)
    sheet.write(i+1,1,wrtmericline[0])
    sheet.write(i+1,3,wrtmericline[1])
    sheet.write(i+1,4,wrtmericline[2])
    sheet.write(i+1,5,wrtmericline[3])
    sheet.write(i+1,2,Total[i]/100) 
filename = 'Merics'+'.xls'
workbook.save(lrmetrics +filename)  # 保存工作簿

selectedp=allf[0:maxid]
index = len(selectedp)  # 获取需要写入数据的行数
workbook = xlwt.Workbook()  # 新建一个工作簿
sheet = workbook.add_sheet('sheet_name')  # 在工作簿中新建一个表格
linehead=['No.']
for j in range(0, len(linehead)):
    sheet.write(0, j, linehead[j])
for i in range(0, index):
    sheet.write(i+1,0,selectedp[i])   
filename = 'Selected properties'+datafilename+'.xls'
workbook.save(mplearn +filename) 
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Records production done')  
print('best AUC: '+maxaucvalue)
print('No. of dimensions: '+str(maxid))
print("If you want to perform independent test, please run TEST.py with parametres confirmed")
    
