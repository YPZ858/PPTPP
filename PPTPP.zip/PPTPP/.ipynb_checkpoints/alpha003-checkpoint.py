def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn
import os
import argparse
import sys
#from beta007 import runrank


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", type=int, help="start index", default=1)
    parser.add_argument("-i", type=str, help="input file",default=tcsv)
    parser.add_argument("-e", type=int, help="end index", default=-1)
    parser.add_argument("-l",  type=int, help="step length", default=1)
    parser.add_argument("-m", type=int, help="mrmd2.0 features top n",default=-1)
    parser.add_argument("-t", type=str, help="metric basline", default="f1")

    args = parser.parse_args()

    return args

if __name__ == '__main__':
    
    __spec__ = None
    tcsv=os.getcwd()+'\\test.csv'
    #from beta007 import runrank
    args=parse_args()
    from beta007 import runrank
    runrank(args)
    #from beta007 import runrank
    
print('tai jier fanrenl')
#os.exit()
#sys.exit()