#!/usr/bin/env python3
# -*- coding=utf-8 -*-

### 消除警告
def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from feature_Rank import feature_rank
import argparse
import sklearn.metrics
import time
import logging
import os
from scipy.io import arff
from sklearn.datasets import load_svmlight_file
from sklearn.datasets import dump_svmlight_file
from format import pandas2arff
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from math import  ceil

tcsv=os.getcwd()+'\\Results\\PBP\\Data\\Level1\\Data\\all_features_for_MRMD.csv'

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", type=int, help="start index", default=1)
    parser.add_argument("-i", type=str, help="input file",default=tcsv)
    parser.add_argument("-e", type=int, help="end index", default=-1)
    parser.add_argument("-l",  type=int, help="step length", default=1)
    parser.add_argument("-m", type=int, help="mrmd2.0 features top n",default=-1)
    parser.add_argument("-t", type=str, help="metric basline", default="f1")

    args = parser.parse_args()

    return args

class Dim_Rd(object):

    def __init__(self,file_csv,logger):
        self.file_csv=file_csv
        self.logger = logger
    def read_data(self):  #default csv

        def read_csv():
            self.df = pd.read_csv(self.file_csv,engine='python').dropna(axis=1)
            datas = np.array(self.df)
            self.datas = datas
            self.X = datas[:, 1:]
            self.y = datas[:, 0]

        file_type = self.file_csv.split('.')[-1]
        if file_type == 'csv':
            read_csv()

    def range_steplen(self, start=1, end=1, length=1):
        self.start = start
        self.end = end
        self.length = length

    def run(self,inputfile):

        args = parse_args()
        file = inputfile

        mrmr_featurLen = args.m
        features,features_sorted=feature_rank(file,self.logger,mrmr_featurLen)
        self.read_data()
        if int(args.e) == -1:
            args.e = len(pd.read_csv(file,engine='python').columns) - 1
        self.range_steplen(args.s, args.e, args.l)

def arff2csv(file):
    data = arff.loadarff(file)
    df = pd.DataFrame(data[0])
    df['class'] = df['class'].map(lambda x:x.decode())

    # eg: 0  1    2     3     4  mean =>>  mean   0     1     2    3    4 in dataframe
    cols = df.columns.tolist()
    cols = cols[-1:] + cols[:-1]
    df = df[cols]

    file_csv = file+'.csv'
    df.to_csv(file_csv,index=None)
    return file_csv

def libsvm2csv(file):
    data = load_svmlight_file(file)
    df = pd.DataFrame(data[0].todense())
    df['class'] = pd.Series(np.array(data[1])).astype(int)

    # eg: 0  1    2     3     4  mean =>>  mean   0     1     2    3    4 in dataframe
    cols = df.columns.tolist()
    cols = cols[-1:] + cols[:-1]
    df = df[cols]

    file_csv = file + '.csv'
    df.to_csv(file_csv, index=None)

    return file_csv


def tsne_scatter(file):

    df = pd.read_csv(file,engine='python')
    tsne = TSNE()

    label_name = df.columns.values[0]
    fea_data = df.drop(columns=[label_name])  # 取出所有特征向量用于降维
    redu_fea = tsne.fit_transform(fea_data)  # 将数据降到2维进行后期的可视化处理
    labels = df.iloc[:,0]
    redu_data = np.vstack((redu_fea.T, labels.T)).T  # 将特征向量和正反例标签整合
    tsne_df = pd.DataFrame(
        data=redu_data, columns=['Dimension1', 'Dimension2', "label"])

    scaler =MinMaxScaler()
    tsne_df[['Dimension1', 'Dimension2']] = scaler.fit_transform(tsne_df[['Dimension1', 'Dimension2']])
    p1 = tsne_df[(tsne_df.iloc[:,2] == 1)]
    p2 = tsne_df[(tsne_df.iloc[:,2] == 0)]
    x1 = p1.values[:, 0]
    y1 = p1.values[:, 1]
    x2 = p2.values[:, 0]
    y2 = p2.values[:, 1]

    # 绘制散点图
    plt.plot(x1, y1, 'o', color="#3dbde2", label='positive',markersize='1')
    plt.plot(x2, y2, 'o', color="#b41f87", label='negative', markersize='1')
    plt.xlabel('Dimension1', fontsize=9)
    plt.ylabel('Dimension2', fontsize=9)

    plt.legend(loc="upper right",fontsize="x-small")



if __name__ == '__main__':

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    log_path = os.getcwd() + os.sep+'Logs'+os.sep
    rq = time.strftime('%Y%m%d%H%M', time.localtime(time.time()))
    log_name = log_path + rq + '.log'
    logfile = log_name
    fh = logging.FileHandler(logfile, mode='w')
    fh.setLevel(logging.INFO)

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)

    # logging.basicConfig(level=logging.INFO,
    #                     format='[%(asctime)s]: %(message)s')  # logging.basicConfig函数对日志的输出格式及方式做相关配置
    formatter = logging.Formatter('[%(asctime)s]: %(message)s')
    #文件
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    #控制台
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    logger.info("---mrmd 2.0 start----")

    args = parse_args()
    file = args.i
    file_type = file.split('.')[-1]
    if file_type == 'csv':
        pass
    elif file_type == 'arff':
        file = arff2csv(file)
    elif file_type == 'libsvm':

        file = libsvm2csv(file)
    else:
        assert "format error"
    #format : arff or libsvm to csv
    d=Dim_Rd(file,logger)
    d.run(inputfile=file)

    logger.info("---mrmd 2.0 end---")
