#!/usr/bin/env python3
# -*- coding=utf-8 -*-

### 消除警告
def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from feature_Rank import feature_rank
import argparse
import sklearn.metrics
import time
import logging
import os
from scipy.io import arff
from sklearn.datasets import load_svmlight_file
from sklearn.datasets import dump_svmlight_file
from format import pandas2arff
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from math import  ceil

tcsv=os.getcwd()+'\\Results\\PBP\\Data\\Level1\\Data\\all_features_for_MRMD.csv'
logger = logging.getLogger()
logger.handlers.clear()
logger.setLevel(logging.INFO)

log_path = os.getcwd() + os.sep+'Logs'+os.sep
rq = time.strftime('%Y%m%d%H%M', time.localtime(time.time()))
log_name = log_path + rq + '.log'
logfile = log_name
fh = logging.FileHandler(logfile, mode='w')
fh.setLevel(logging.INFO)

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)

formatter = logging.Formatter('[%(asctime)s]: %(message)s')

fh.setFormatter(formatter)
logger.addHandler(fh)

file=tcsv

ch.setFormatter(formatter)
logger.addHandler(ch)
logger.info("---mrmd 2.0 start----")

features,features_sorted=feature_rank(file,logger,1)

logger.info("---mrmd 2.0 end---")
