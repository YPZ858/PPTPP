print('ccc')


qs=1
print(qs)
#!/usr/bin/env python3
# -*- coding=utf-8 -*-
import os
from beta007 import runrank
import argparse
tcsv=os.getcwd()+'\\Results\\PBP\\Data\\Level1\\Data\\all_features_for_MRMD.csv'
print('ppp')
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", type=int, help="start index", default=1)
    parser.add_argument("-i", type=str, help="input file",default=tcsv)
    parser.add_argument("-e", type=int, help="end index", default=-1)
    parser.add_argument("-l",  type=int, help="step length", default=1)
    parser.add_argument("-m", type=int, help="mrmd2.0 features top n",default=-1)
    parser.add_argument("-t", type=str, help="metric basline", default="f1")

    args = parser.parse_args()

    return args
qs=2
print('mmp')
if __name__ == '__main__':
    __spec__ = None
    args=parse_args()
    runrank(args)
