import numpy as np
import matplotlib.pyplot as plt
import math
import random
import xlrd
import xlwt
import csv
import pandas as pd
import weka.core.jvm as jvm
import weka.core.packages as packages
from weka.classifiers import Classifier
from weka.core.converters import Loader
from weka.core.dataset import Instances
from weka.classifiers import Classifier
import weka.core.serialization as serialization
from weka.classifiers import Classifier
import traceback
import os
from weka.classifiers import Classifier
import scipy.stats.stats as st
import sys
import sys, getopt
import openpyxl    

codepath='C:\\Users\\heartunderblade\\Documents\\YPZ\\Codes'
# Setting general parameters
datafilename='QSPT' # Name of the data file
rawdir=codepath+'\\raw\\' # Folder where you place the data
prodir=codepath+'\\processed2\\' # Folder where you wish to place the
print('Programme started')
data_AAraw = open(codepath+'\\raw\\AAindex_raw.txt') # Folder where you place the raw AAindex data, the default is the path where you place this code
# PART 1 AAindex loading and standardisation
#Load AA index,
print('AAinedx loading started ') # AA index loaded at this step was unmodified

preAAmatrix=[]
AAmatrix0 = []
element = []

def norm(x):# For AAindex standardisation
    use =[]
    for i in range(len(x)):
        x[i]=float(x[i])
    arr_mean = np.mean(x)
    arr_std = np.std(x,ddof=0)
    for k in range(len(x)):
        ele = (x[k]-arr_mean)/arr_std
        use.append(ele)
    return use

trig=0
for line in data_AAraw.readlines(): #read numerical values from AAindex rawfile
    if "A/L" in line:
        trig = 1
        continue
    if trig ==1:  
        for i in range(len(line)):
            if line[i]!=' ':
                element+=line[i]
                if i<len(line)-1:
                    if line[i+1]==' 'or line[i+1]=='\n':
                       element2=''.join(element)
                       preAAmatrix.append(element2)
                       element = []                         
        trig = trig+1
        continue
    if trig ==2:
        element = []
        for i in range(len(line)):
            if line[i]!=' ':
                element+=line[i] 
                if i<len(line)-1:
                    if line[i+1]==' 'or line[i+1]=='\n':
                       element2=''.join(element)
                       preAAmatrix.append(element2)
                       element = []                         
        trig = 0
    if preAAmatrix!=[]:
        AAmatrix0.append(preAAmatrix)  
    preAAmatrix = []
    element = []
print('Raw AAindex loading done')
def cleanNA(x): # To remove properties containing null value
    new = []
    nl = []
    for i in range(len(x)):
        linex = x[i]
        for j in range(len(linex)):
            if linex[j]!='NA':
                ele = float(linex[j])
                nl.append(ele)
        if len(nl)==20:
            new.append(nl)
        nl = []
    return new
AAmatrix0=cleanNA(AAmatrix0)
for i in range(len(AAmatrix0)):
    AAmatrix0[i]=norm(AAmatrix0[i])

def getcol(x):
    col = pd.read_excel(prodir+datafilename[0:len(datafilename)-1]+'BF\\'+'Selected properties'+datafilename[0:len(datafilename)-1]+'.xls', usecols=[x])
    col_list = col.values.tolist()
    result = []
    for col_listx in col_list:
        result.append(col_listx[0])
    return result
selectedp=getcol(0)
                        
AAmatrix=[]
                        
for i in range(len(selectedp)):
    AAmatrix.append(AAmatrix0[(selectedp[i]-1)])

print('AAindex standardisation done')

# PART 2 Sequence encoding
acalpbt =['A','R','N','D','C','Q','E','G','H','I','L','K','M','F','P','S','T','W','Y','V']
data = open(rawdir+datafilename+'.txt')
seqtype =[]
seqcont =[]
# Loading the sequence information from relevant FAST files
for line in data.readlines():
    if ">" in line:
        seqtype.append(line[len(line)-2])
    else:
        if line[len(line)-1]!='\n':
            line.strip()
            seqcont.append(line)
        else: 
            line.strip()
            seqcont.append(line[0:len(line)-1])
        
if len(seqtype)==len(seqcont):
    print ('number of label and sequences is the same')
    num = len(seqtype)
# Store positive and negative samples separately
t=[]
f=[]
cot=0
cof=0
for p in range(num):
    if seqtype[p]=='1':
        t.append(seqcont[p])
        cot=cot+1
    else:
        f.append(seqcont[p])
        cof=cof+1

list_newseqA=t
list_newseqB=f
list_newseqC=[]
print('sequences loading done') 
AAinline = []
AAinlineZ = []
AAinlineJ = []
A=[]
m=[]
mm=[]
jj=[]
zz=[]
jx=[]
z=[]

# Direct encoding of sequences using standardised AAindex
for i in range(len(AAmatrix)):
    AAline = AAmatrix[i]
    for j in range(len(list_newseqA)):
        hseq = list_newseqA[j]
        for k in range(len(hseq)):
            hre = hseq[k]
            for p in range(len(acalpbt)):
                if hre == acalpbt[p]:
                   AAinline.append(AAline[p])
        z.append(AAinline)
        AAinline = []
    zz.append(z)
    z=[]
    
    AAinline = []
    for j in range(len(list_newseqB)):
        hseq = list_newseqB[j]
        for k in range(len(hseq)):
            hre = hseq[k]
            for p in range(len(acalpbt)):
                if hre == acalpbt[p]:
                   AAinline.append(AAline[p])
        jx.append(AAinline)
        AAinline = []
    jj.append(jx)
    jx=[]

print('direct encoding done')

def corre(x,n): #Auto-correlation function
    q=np.correlate(x, x, mode = 'full')
    return q[n]/(len(x)-n)         
#10D descriptor
def AAcal(seqcont,va):
    v=[]
    for i in range(len(seqcont)):
        vtar=seqcont[i]
        vtar1=0
        vtar2=0
        vtar3=0
        vtar4=0
        vtar5=0
        vtar6=0
        vtar7=0
        vtar8=0
        vtar9=0
        vtarv=[]
        s = pd.Series(vtar)    
        vtar0=corre(vtar,int(len(vtar)*0.25)) # These 3 dimensions are resulted from autocorrelation
        vtar1=corre(vtar,int(len(vtar)*0.5))
        vtar2=corre(vtar,int(len(vtar)*0.75))
        vtar10=corre(vtar,0)
        vtar3=np.mean(vtar)  # These 4 dimensions are relevant statistical terms
        vtar4=st.kurtosis(vtar)
        vtar5=np.std(vtar,ddof=0)
        vtar6=st.skew(vtar)
        for p in range(len(vtar)): # These 3 dimensions are inspired by PAFIG algorithm
            vtar7=vtar[p]**2+vtar7
            if vtar[p]>0:
                vtar8=vtar[p]**2+vtar8
            else:
                vtar9=vtar[p]**2+vtar9  
        vtarv.append(vtar0)
        vtarv.append(vtar1)
        vtarv.append(vtar2)
        vtarv.append(vtar10)
        vtarv.append(vtar3)
        vtarv.append(vtar4)
        vtarv.append(vtar5)
        vtarv.append(vtar6)
        vtarv.append(vtar7)
        vtarv.append(vtar8)
        vtarv.append(vtar9)
        v.append(vtarv)
    return v
# Store relevant features
bigZ=[]
for i in range(len(zz)):
    zline = AAcal(zz[i],0)
    bigZ.append(zline)
bigJ=[]
for i in range(len(jj)):
    jline = AAcal(jj[i],0)
    bigJ.append(jline)
big=[]
for i in range(len(jj)):
    bigm = bigZ[i]+bigJ[i]
    big.append(bigm)
print('feature extraction done')

def addlable(W1): # function for labelling input data
   for i in range(len(W1)):
       lineprc = W1[i]
       if i<cot:
           lineprc.append('NO')
       if i>=cot:
           lineprc.append('YES')
    
def addID(W1): # function for adding ID to input data
   for i in range(len(W1)):
       lineprc = W1[i]
       lineprc.insert(0,i)
                   
for i in range(len(big)): # label the input data
    addlable(big[i])

for i in range(len(big)):# Add ID to the input data
    addID(big[i])
    
def xlsx_to_csv_pd(a,b):
    data_xls = pd.read_excel(a, index_col=0)
    data_xls.to_csv(b, encoding='utf-8')
#Create the folder storing CSV files 
os.makedirs(prodir+datafilename+'CSV\\', exist_ok=True)
print('file production started')
#Write the 10D vector of samples to a CSV sheet
for p in range(len(big)):
    W1 = big[p]
    index = len(W1)  # Number of sequences
    nbtitle = ['ID','T1','T2','T3','T4','T5','T6','T7','class']
    workbook = xlwt.Workbook()  
    sheet = workbook.add_sheet('sheet_name')  
    for i in range(0, index+1):
       if i==0:
          for j in range(0, len(nbtitle)):
             sheet.write(i, j, nbtitle[j])
       else:
          for j in range(0, len(W1[i-1])):
             lineprc = W1[i-1]
             sheet.write(i, j, lineprc[j]) 
       featype='Feature'
       fspath= prodir+datafilename+'CSV\\'
       filename = featype+str(p)+'CSV'+'.xls'
       filename2 = featype+str(p)+'CSV'+'.csv'
    workbook.save(fspath+filename) 
    xlsx_to_csv_pd(fspath+filename,fspath+filename2)
    os.remove(fspath+filename)
print('CSV feature now produced')
print('convertion to .ARFF started')
#Create the folder storing ARFF files 
os.makedirs(prodir+datafilename+'ARFF\\', exist_ok=True)
#Convert the CSV to ARFF, the following code was derived from online sources under Apache License 2.0, details can be found in readme
for mm in range(len(selectedp)):
    NfileIn = fspath +featype+str(mm)+'CSV'+'.csv'
    NfileOut=prodir+datafilename+'ARFF\\'+featype+str(mm)+'ARFF'+'.arff'

    fileIn = open(NfileIn);
    fileOut = open(NfileOut,"w")
    relation = "conversion"

    f = open(NfileIn, 'r')
    reader = csv.reader(f)
    datapoints = list(reader)
    attributes = datapoints [0]

    lastPos = fileIn.tell()

    fileOut.write("%\n% Comments go after a '%' sign.\n%\n")
    fileOut.write("%\n% Relation: " + relation +"\n%\n%\n")
    fileOut.write("% Attributes: " + str(len(attributes)) + " "*5 
	    + "Instances: " + str(len(datapoints)-1) + "\n%\n%\n\n")
    fileOut.write("@relation " + relation + "\n\n")
    count=1
    for k in range(len(fileIn.readline().strip().split(','))-1):
	    fileOut.write("@attribute" + " '" + attributes[k] 
		    + "'" + " numeric\n")
	    count+=1
	
    fileOut.write("@attribute"+ " '" + str(attributes[len(attributes)-1])+"' "
                  +"{'no'"+"'yes'}\n")	
    fileOut.write("\n@data\n");

    fileIn.seek(lastPos)

    tempStr = []

    for line in fileIn:
        if line[0]!='I':
            for i in range(len(line.strip().split(','))):
                if i==len(line.strip().split(','))-1:
                    tempStr.append("'"+(line.strip().split(',')[i]).lower()+"'")
                else:
                    tempStr.append(line.strip().split(',')[i])
            fileOut.write(','.join(tempStr)+"\n")
        tempStr= []
        

    fileOut.close()
print('conversion done')
print('Cross validation started')

#Start JVM for employing WEKA
jvm.start(packages=True)

#Create the folder storing details of computing outcome 
os.makedirs(prodir+datafilename+'BF\\', exist_ok=True)

data_dir = prodir+datafilename+'ARFF\\'
save_dir = prodir+datafilename+'BF\\'

Total=[]
model_dir= prodir+datafilename[0:len(datafilename)-1]+'BF\\'
for i in range(len(selectedp)):
    nasavesumary='sumary'+str(i)
    nasavebuffer='buffer'+str(i)
    nasavedetail='detail'+str(i)
    savesumary=open(save_dir+nasavesumary+'.txt','w')
    savebuffer=open(save_dir+nasavebuffer+'.txt','w')
    savedetail=open(save_dir+nasavedetail+'.txt','w')
    filename2 = featype+str(i)+'ARFF'+'.arff'
    loader = Loader(classname="weka.core.converters.ArffLoader")
    data = loader.load_file(data_dir + filename2)
    data.class_is_last()

    import weka.core.serialization as serialization
    # previously built classifier
    cls = Classifier(jobject=serialization.read(model_dir+"P"+str(int(selectedp[i])-1)+".model"))

    from weka.classifiers import Evaluation
    from weka.classifiers import PredictionOutput
    pout = PredictionOutput(classname="weka.classifiers.evaluation.output.prediction.PlainText",options=["-p","1"])
    evl = Evaluation(data)
    evl.test_model(cls, data, pout)
    print('now processing'+'NO.'+str(i+1))
    Total.append(evl.percent_correct)
    
    savesumary.writelines(evl.summary())
    savesumary.close()
    savebuffer.writelines(pout.buffer_content())
    savebuffer.close()
    savedetail.writelines(evl.class_details())
    savedetail.close()
    
print('weka work done')
#Write the merics of all properties
data_dirx= prodir+datafilename+'BF\\'#Folder storing all training detail
def readSP(x): #read specificity
    data=open(x)
    for line in data.readlines():
        if line[96:97]=='o':
            ppp=line[17:24]      
    return ppp

def readSE(x):#read sensitivity
    data=open(x)
    for line in data.readlines():
        if line[96:97]=='e':
            ppp=line[17:24]      
    return ppp

def readMCC(x):#read MCC
    data=open(x)
    for line in data.readlines():
        if line[0]=='W':
            ppp=line[66:71]      
    return ppp

def readAUC(x):
    data=open(x)
    for line in data.readlines():
        if line[0]=='W':
            ppp=line[75:80]      
    return ppp

merics=[]
for i in range(len(selectedp)):
    mericline=[]
    mericfile=data_dirx+'detail'+str(i)+'.txt'
    mericline.append(readAUC(mericfile))
    mericline.append(readMCC(mericfile))
    mericline.append(readSE(mericfile))
    mericline.append(readSP(mericfile))
    merics.append(mericline)
    
data_dir2= prodir+datafilename+'BF\\'             
index = len(merics)  # 获取需要写入数据的行数
workbook = xlwt.Workbook()  # 新建一个工作簿
sheet = workbook.add_sheet('sheet_name')  # 在工作簿中新建一个表格
linehead=['No.','AUC','ACC','MCC','SE','SP']
for j in range(0, len(linehead)):
    sheet.write(0, j, linehead[j])
for i in range(0, index):
    wrtmericline=merics[i]
    sheet.write(i+1,0,i+1)
    sheet.write(i+1,1,wrtmericline[0])
    sheet.write(i+1,3,wrtmericline[1])
    sheet.write(i+1,4,wrtmericline[2])
    sheet.write(i+1,5,wrtmericline[3])
    sheet.write(i+1,2,Total[i]) 
filename = 'Merics'+'.xls'
workbook.save(data_dir2 +filename)  # 保存工作簿


print('531D 1/0 vector production started')
#Produce 531 1/0 vectors based on previous training outcome (10-cross validation)
data_dir2= prodir+datafilename+'BF\\'
newID=np.arange(0,len(seqcont)+20,1)
allbi=[]
for j in range(len(selectedp)):
    linebi=[]
    data=open(data_dir2+'buffer'+str(j)+'.txt')
    typ=[]
    ID=[]
    for line in data.readlines():
        if line[30]=='d':
            continue
        srt=0
        for i in range(len(line)):
            if line[i]=='(' and line[i+1]!='I':
                srt=i
            if line[i]==')'and line[i-1]!='D':
                stp=i
        prv=float(line[38:srt-1])
        if line[30]=='s':
            typ.append(prv)
        if line[30]=='o':
            typ.append(1-prv)
        if srt>0:
            ID.append(int(line[srt+1:stp]))
    for k in range(len(newID)):
        for p in range(len(ID)):
            if newID[k]==ID[p]:
                linebi.append(typ[p])
    allbi.append(linebi)
    print('now processing No. '+str(j+1)+'out of '+str(len(selectedp)))
                
def nbgenea(n):#function for producing the headline in later sheet
    qq=[]
    for i in range(n):
        fname='f'+str(i+1)
        qq.append(fname)
    qq.append('class')
    return qq

def nbgeneb(n):#function for producing the headline in later sheet, which shall be processed by MRMD2.0
    qq=[]
    ko=[]
    for i in range(n):
        fname='f'+str(i+1)
        qq.append(fname)
    ko.append('class')
    ko=ko+qq
    return ko
print('Optimised 1/0 vector production done')
print('record production started')

#Produce the sheets containing all features, normal format 
W1 = allbi    
index = len(W1) 
nbtitle = nbgenea(531)
datasave = openpyxl.Workbook()  
datasave.create_sheet('Sheet1')
table = datasave.active
table.cell(1, 1, 'ID')
table.cell(1, len(selectedp)+2, 'class')
for i in range(len(selectedp)):
    table.cell(1, i+2, 'f'+str(selectedp[i]))
for j in range(index):
    each = W1[j]
    for k in range(len(each)):
        table.cell(k+2, j+2, each[k])
        table.cell(k+2, 1, k+1)
        if k<cot:
            table.cell(k+2, index+2, 'NO')
        if k>=cot:
            table.cell(k+2, index+2, 'YES') 
filenamex = 'optimised_properties'
datasave.save(data_dir2+filenamex+'.xls')
xlsx_to_csv_pd(data_dir2+filenamex+'.xls',data_dir2+filenamex+'.csv')
datasave.close()

for mm in range(1):
    NfileIn = data_dir2+filenamex+'.csv'
    NfileOut= data_dir2+filenamex+'.arff'

    fileIn = open(NfileIn);
    fileOut = open(NfileOut,"w")
    relation = "conversion"

    f = open(NfileIn, 'r')
    reader = csv.reader(f)
    datapoints = list(reader)
    attributes = datapoints [0]

    lastPos = fileIn.tell()

    fileOut.write("%\n% Comments go after a '%' sign.\n%\n")
    fileOut.write("%\n% Relation: " + relation +"\n%\n%\n")
    fileOut.write("% Attributes: " + str(len(attributes)) + " "*5 
	    + "Instances: " + str(len(datapoints)-1) + "\n%\n%\n\n")
    fileOut.write("@relation " + relation + "\n\n")
    count=1
    for k in range(len(fileIn.readline().strip().split(','))-1):
	    fileOut.write("@attribute" + " '" + attributes[k] 
		    + "'" + " numeric\n")
	    count+=1
	
    fileOut.write("@attribute"+ " '" + str(attributes[len(attributes)-1])+"' "
                   +"{'no'"+"'yes'}\n")	
    fileOut.write("\n@data\n");

    fileIn.seek(lastPos)

    tempStr = []

    for line in fileIn:
        if line[0]!='I':
            for i in range(len(line.strip().split(','))):
                if i==len(line.strip().split(','))-1:
                    tempStr.append("'"+(line.strip().split(',')[i]).lower()+"'")
                else:
                    tempStr.append(line.strip().split(',')[i])
            fileOut.write(','.join(tempStr)+"\n")
        tempStr= []
        
    fileOut.close()

maxid=len(selectedp)-1
model_dir2= prodir+datafilename[0:len(datafilename)-1]+'SF\\'
for i in range(1):
    nasavesumary='OPTsumary'+str(i)
    nasavebuffer='OPTbuffer'+str(i)
    nasavedetail='OPTdetail'+str(i)
    savesumary=open(save_dir+nasavesumary+'.txt','w')
    savebuffer=open(save_dir+nasavebuffer+'.txt','w')
    savedetail=open(save_dir+nasavedetail+'.txt','w')
    loader = Loader(classname="weka.core.converters.ArffLoader")
    data = loader.load_file(data_dir2+filenamex+'.arff')
    data.class_is_last()

    import weka.core.serialization as serialization
    # previously built classifier
    cls = Classifier(jobject=serialization.read(model_dir2+"P"+str(maxid)+".model"))

    from weka.classifiers import Evaluation
    from weka.classifiers import PredictionOutput
    pout = PredictionOutput(classname="weka.classifiers.evaluation.output.prediction.PlainText",options=["-p","1"])
    evl = Evaluation(data)
    evl.test_model(cls, data, pout)
    print('now processing'+'NO.'+str(i+1))
    Total.append(evl.percent_correct)
    
    savesumary.writelines(evl.summary())
    savesumary.close()
    savebuffer.writelines(pout.buffer_content())
    savebuffer.close()
    savedetail.writelines(evl.class_details())
    savedetail.close()
print('done')