import os
import argparse
import sys

codepath=os.getcwd()
os.system("Training5.4.py")

npathdata=prodir+'Data\\'
npathmetric=prodir+'Metrics\\'

npathlevel1=npathdata+'Level1\\'
npathlevel2=npathdata+'Level2\\'
arfflevel1=npathlevel1+'Arff\\'
arfflevel2=npathlevel2+'Arff\\'
datalevel1=npathlevel1+'Data\\'
datalevel2=npathlevel2+'Data\\'
modellevel1=npathlevel1+'Model\\'
modellevel2=npathlevel2+'Model\\'
mpmetrics=npathmetric+'531 Metrics\\'
mplearn=npathmetric+'Learning\\'

data_dir2= datalevel1
tcsv=data_dir2+filenamex2
filenamex2 = 'all_features_for_MRMD'+'.csv'

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", type=int, help="start index", default=1)
    parser.add_argument("-i", type=str, help="input file",default=tcsv)
    parser.add_argument("-e", type=int, help="end index", default=-1)
    parser.add_argument("-l",  type=int, help="step length", default=1)
    parser.add_argument("-m", type=int, help="mrmd2.0 features top n",default=-1)
    parser.add_argument("-t", type=str, help="metric basline", default="f1")

    args = parser.parse_args()

    return args

if __name__ == '__main__':
    __spec__ = None
    args=parse_args()
    from mrmdrk import runrank
    runrank(args,mplearn)

