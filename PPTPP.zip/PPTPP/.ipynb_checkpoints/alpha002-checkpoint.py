import warnings
import argparse
import time
import logging
import os

tcsv=os.getcwd()+'\\test.csv'

logger = logging.getLogger()
logger.handlers.clear()
logger.setLevel(logging.INFO)

log_path = os.getcwd() + os.sep+'Logs'+os.sep
rq = time.strftime('%Y%m%d%H%M', time.localtime(time.time()))
log_name = log_path + rq + '.log'
logfile = log_name
fh = logging.FileHandler(logfile, mode='w')
fh.setLevel(logging.INFO)

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)

def xxx(a):
    print(str(a))
if __name__ == '__main__':
    xxx(12)
    xxx(11)
    __spec__ = None
    
    formatter = logging.Formatter('[%(asctime)s]: %(message)s')
    #文件
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    #控制台
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    logger.info("---mrmd 2.0 start----")
    
    #from feature_Rank import feature_rank
    features,features_sorted=feature_rank(tcsv,logger,1)
    from feature_Rank import feature_rank

