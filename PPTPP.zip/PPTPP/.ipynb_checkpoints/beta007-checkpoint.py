#!/usr/bin/env python3
# -*- coding=utf-8 -*-

### 消除警告
def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import argparse
import sklearn.metrics
import time
import logging
import os
from scipy.io import arff
from sklearn.datasets import load_svmlight_file
from sklearn.datasets import dump_svmlight_file
from format import pandas2arff
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from math import  ceil
from feature_Rank import feature_rank

tcsv=os.getcwd()+'\\Results\\PBP\\Data\\Level1\\Data\\all_features_for_MRMD.csv'

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", type=int, help="start index", default=1)
    parser.add_argument("-i", type=str, help="input file",default=tcsv)
    parser.add_argument("-e", type=int, help="end index", default=-1)
    parser.add_argument("-l",  type=int, help="step length", default=1)
    parser.add_argument("-m", type=int, help="mrmd2.0 features top n",default=-1)
    parser.add_argument("-t", type=str, help="metric basline", default="f1")

    args = parser.parse_args()

    return args

class Dim_Rd(object):

    def __init__(self,file_csv,logger):
        self.file_csv=file_csv
        self.logger = logger
    def read_data(self):  #default csv

        def read_csv():
            self.df = pd.read_csv(self.file_csv,engine='python').dropna(axis=1)
            datas = np.array(self.df)
            self.datas = datas
            self.X = datas[:, 1:]
            self.y = datas[:, 0]

        file_type = self.file_csv.split('.')[-1]
        if file_type == 'csv':
            read_csv()

    def range_steplen(self, start=1, end=1, length=1):
        self.start = start
        self.end = end
        self.length = length

    def run(self,inputfile):

        args = parse_args()
        file = inputfile
        mrmr_featurLen = args.m
        features,features_sorted=feature_rank(file,self.logger,mrmr_featurLen)
        self.read_data()
        if int(args.e) == -1:
            args.e = len(pd.read_csv(file,engine='python').columns) - 1
        self.range_steplen(args.s, args.e, args.l)

def runrank(args):
    pk=0
    __spec__ = None
    logger = logging.getLogger()
    logger.handlers.clear()
    logger.setLevel(logging.INFO)

    log_path = os.getcwd() + os.sep+'Logs'+os.sep
    rq = time.strftime('%Y%m%d%H%M', time.localtime(time.time()))
    log_name = log_path + rq + '.log'
    logfile = log_name
    fh = logging.FileHandler(logfile, mode='w')
    fh.setLevel(logging.INFO)

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)

    # logging.basicConfig(level=logging.INFO,
    #                     format='[%(asctime)s]: %(message)s')  # logging.basicConfig函数对日志的输出格式及方式做相关配置
    formatter = logging.Formatter('[%(asctime)s]: %(message)s')
    #文件
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    #控制台
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    logger.info("---mrmd 2.0 start----")

    file = args.i
    #format : arff or libsvm to csv
    d=Dim_Rd(file,logger)
    d.run(inputfile=file)

    logger.info("---mrmd 2.0 end---")
