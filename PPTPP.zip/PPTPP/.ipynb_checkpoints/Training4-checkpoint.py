import numpy as np
import matplotlib.pyplot as plt
import math
import random
import xlrd
import xlwt
import csv
import pandas as pd
import weka.core.jvm as jvm
import weka.core.packages as packages
from weka.classifiers import Classifier
from weka.core.converters import Loader
from weka.core.dataset import Instances
from weka.classifiers import Classifier
import weka.core.serialization as serialization
from weka.classifiers import Classifier
import traceback
import os
from weka.classifiers import Classifier
import scipy.stats.stats as st
import sys
import sys, getopt
import openpyxl    
import arff

codepath='C:\\Users\\heartunderblade\\Documents\\YPZ\\Codes'
# Setting general parameters
datafilename='PBP' # Name of the data file
rawdir=codepath+'\\raw\\' # Folder where you place the data
prodir=codepath+'\\processed2\\' # Folder where you wish to place the processed data
data_AAraw = open(codepath+'\\raw\\AAindex_raw.txt') # Folder where you place the raw AAindex data, the default is the path where you place this code
#auto-selection of computing mode, following the name of the datafile


print('Programme started')

# PART 1 AAindex loading and standardisation
#Load AA index,
print('AAinedx loading started ') # AA index loaded at this step was unmodified

preAAmatrix=[]
AAmatrix = []
element = []

def norm(x):# For AAindex standardisation
    use =[]
    for i in range(len(x)):
        x[i]=float(x[i])
    arr_mean = np.mean(x)
    arr_std = np.std(x,ddof=0)
    for k in range(len(x)):
        ele = (x[k]-arr_mean)/arr_std
        use.append(ele)
    return use

trig=0
for line in data_AAraw.readlines(): #read numerical values from AAindex rawfile
    if "A/L" in line:
        trig = 1
        continue
    if trig ==1:  
        for i in range(len(line)):
            if line[i]!=' ':
                element+=line[i]
                if i<len(line)-1:
                    if line[i+1]==' 'or line[i+1]=='\n':
                       element2=''.join(element)
                       preAAmatrix.append(element2)
                       element = []                         
        trig = trig+1
        continue
    if trig ==2:
        element = []
        for i in range(len(line)):
            if line[i]!=' ':
                element+=line[i] 
                if i<len(line)-1:
                    if line[i+1]==' 'or line[i+1]=='\n':
                       element2=''.join(element)
                       preAAmatrix.append(element2)
                       element = []                         
        trig = 0
    if preAAmatrix!=[]:
        AAmatrix.append(preAAmatrix)  
    preAAmatrix = []
    element = []
print('Raw AAindex loading done')
print('AAindex standardisation started')
def cleanNA(x): # To remove properties containing null value
    new = []
    nl = []
    for i in range(len(x)):
        linex = x[i]
        for j in range(len(linex)):
            if linex[j]!='NA':
                ele = float(linex[j])
                nl.append(ele)
        if len(nl)==20:
            new.append(nl)
        nl = []
    return new
AAmatrix=cleanNA(AAmatrix)
for i in range(len(AAmatrix)):
    AAmatrix[i]=norm(AAmatrix[i])
print('AAindex standardisation done')

# PART 2 Sequence encoding
print('Sequence encoding started')
acalpbt =['A','R','N','D','C','Q','E','G','H','I','L','K','M','F','P','S','T','W','Y','V']
data = open(rawdir+datafilename+'.txt')
seqtype =[]
seqcont =[]
# Loading the sequence information from relevant FAST files
for line in data.readlines():
    if ">" in line:
        seqtype.append(line[len(line)-2])
    else:
        if line[len(line)-1]!='\n':
            line.strip()
            seqcont.append(line)
        else: 
            line.strip()
            seqcont.append(line[0:len(line)-1])
        
if len(seqtype)==len(seqcont):
    print ('number of label and sequences is the same')
    num = len(seqtype)
# Store positive and negative samples separately
t=[]
f=[]
cot=0
cof=0
for p in range(num):
    if seqtype[p]=='1':
        t.append(seqcont[p])
        cot=cot+1
    else:
        f.append(seqcont[p])
        cof=cof+1

list_newseqA=t
list_newseqB=f
list_newseqC=[]
print('sequences loading done') 
AAinline = []
AAinlineZ = []
AAinlineJ = []
A=[]
m=[]
mm=[]
jj=[]
zz=[]
jx=[]
z=[]

# Direct encoding of sequences using standardised AAindex
for i in range(len(AAmatrix)):
    AAline = AAmatrix[i]
    for j in range(len(list_newseqA)):
        hseq = list_newseqA[j]
        for k in range(len(hseq)):
            hre = hseq[k]
            for p in range(len(acalpbt)):
                if hre == acalpbt[p]:
                   AAinline.append(AAline[p])
        z.append(AAinline)
        AAinline = []
    zz.append(z)
    z=[]
    
    AAinline = []
    for j in range(len(list_newseqB)):
        hseq = list_newseqB[j]
        for k in range(len(hseq)):
            hre = hseq[k]
            for p in range(len(acalpbt)):
                if hre == acalpbt[p]:
                   AAinline.append(AAline[p])
        jx.append(AAinline)
        AAinline = []
    jj.append(jx)
    jx=[]

print('Direct encoding done')

def corre(x,n): #Auto-correlation function
    q=np.correlate(x, x, mode = 'full')
    return q[n]/(len(x)-n)         
#10D descriptor
def AAcal(seqcont,va):
    v=[]
    for i in range(len(seqcont)):
        vtar=seqcont[i]
        vtarv=[]
        vtar7=0
        vtar8=0
        vtar9=0
        s = pd.Series(vtar)    
        #vtar0=corre(vtar,int(len(vtar)*0.25)) # These 3 dimensions are resulted from autocorrelation
        #vtar1=corre(vtar,int(len(vtar)*0.5))
        #vtar2=corre(vtar,int(len(vtar)*0.75))
        #vtar2a=corre(vtar,0)
        vtar3=np.mean(vtar)  # These 4 dimensions are relevant statistical terms
        vtar4=st.kurtosis(vtar)
        vtar5=np.std(vtar,ddof=0)
        vtar6=st.skew(vtar)
        for p in range(len(vtar)): # These 3 dimensions are inspired by PAFIG algorithm
            vtar7=vtar[p]**2+vtar7
            if vtar[p]>va:
                vtar8=vtar[p]**2+vtar8
            else:
                vtar9=vtar[p]**2+vtar9
        vcf1=[]
        vcf2=[]
        for j in range(len(vtar)-1):
            vcf1.append((vtar[j]-vtar[j+1])**2)
        for k in range(len(vtar)-2):
            vcf2.append((vtar[k]-vtar[k+2])**2)
        vtar10=np.mean(vcf1)
        vtar11=np.std(vcf1,ddof=0)
        vtar12=np.mean(vcf2)
        vtar13=np.std(vcf2,ddof=0)
        #vtarv.append(vtar0)
        #vtarv.append(vtar1)
        #vtarv.append(vtar2)
        #vtarv.append(vtar2a)
        vtarv.append(vtar3)
        vtarv.append(vtar4)
        vtarv.append(vtar5)
        vtarv.append(vtar6)
        vtarv.append(vtar7/len(vtar))
        vtarv.append(vtar8/len(vtar))
        vtarv.append(vtar9/len(vtar))
        vtarv.append(vtar10)
        vtarv.append(vtar11)
        vtarv.append(vtar12)
        vtarv.append(vtar13)
        v.append(vtarv)
    return v

# Store relevant features
bigZ=[]
for i in range(len(zz)):
    zline = AAcal(zz[i],0)
    bigZ.append(zline)
bigJ=[]
for i in range(len(jj)):
    jline = AAcal(jj[i],0)
    bigJ.append(jline)
big=[]
for i in range(len(jj)):
    bigm = bigZ[i]+bigJ[i]
    big.append(bigm)
print('Feature extraction done')

def addlable(W1): # function for labelling input data
   for i in range(len(W1)):
       lineprc = W1[i]
       if i<cot:
           lineprc.append('NO')
       if i>=cot:
           lineprc.append('YES')
    
def addID(W1): # function for adding ID to input data
   for i in range(len(W1)):
       lineprc = W1[i]
       lineprc.insert(0,i)
                   
for i in range(len(big)): # label the input data
    addlable(big[i])

for i in range(len(big)):# Add ID to the input data
    addID(big[i])
    
atb=[]
atbID=('ID','REAL')
atb.append(atbID)
for i in range(11):
    atbf=('f'+str(i+1),'REAL')
    atb.append(atbf)
atbclss=('class', ['NO', 'YES'])
atb.append(atbclss)

os.makedirs(prodir+datafilename+'Narff\\', exist_ok=True)
for i in range(len(big)):
    f=open(prodir+datafilename+'Narff\\'+'arff'+str(i)+'.arff','w')
    W1 = big[i]
    index = len(W1)
    obj = {
        'description': u'',
        'relation': datafilename+'feature',
        'attributes': atb,
        'data':W1,
    }
    f.write(arff.dumps(obj))
    f.close
    
        
        
