def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn
import os
import argparse
import sys
import numpy as np
#from beta007 import runrank
codepath=os.getcwd()

datafilename=str(np.load(codepath+'\\prebig.npy'))[2:-2]
rawdir=codepath+'\\Raw\\' # Folder where you place the data
prodir=codepath+'\\Results\\' +datafilename+'\\'# Folder where you wish to place the processed data

binpath=prodir+'Bin\\'
modelpath=prodir+'Model\\'
metricspath=prodir+'Metrics\\'
arffpath=prodir+'Arff\\'

indbinpath=binpath+'Individual\\'
sfsbinpath=binpath+'SFS\\'
metamodpath=modelpath+'Meta\\'
finlmodpath=modelpath+'Final\\'
indarffpath=arffpath+'Individual\\'
sfsarffpath=arffpath+'SFS\\'

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", type=int, help="start index", default=1)
    parser.add_argument("-i", type=str, help="input file",default=tcsv)
    parser.add_argument("-e", type=int, help="end index", default=-1)
    parser.add_argument("-l",  type=int, help="step length", default=1)
    parser.add_argument("-m", type=int, help="mrmd2.0 features top n",default=-1)
    parser.add_argument("-t", type=str, help="metric basline", default="f1")

    args = parser.parse_args()

    return args

if __name__ == '__main__':
    
    __spec__ = None
    tcsv=indbinpath+'all_features_for_MRMD'+'.csv'
    #from beta007 import runrank
    args=parse_args()
    from mrmdrk import runrank
    runrank(args,metricspath,binpath)

#os.exit()
#sys.exit()
