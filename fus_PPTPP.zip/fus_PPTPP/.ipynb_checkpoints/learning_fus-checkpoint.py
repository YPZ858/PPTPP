import numpy as np
import matplotlib.pyplot as plt
import math
import random
import xlrd
import xlwt
import csv
import pandas as pd
import weka.core.jvm as jvm
import weka.core.packages as packages
from weka.classifiers import Classifier
from weka.core.converters import Loader
from weka.core.dataset import Instances
from weka.classifiers import Classifier
import weka.core.serialization as serialization
from weka.classifiers import Classifier
import traceback
import os
from weka.classifiers import Classifier
import scipy.stats.stats as st
import sys
import sys, getopt
import openpyxl    
import arff
import time

jvm.start(packages=True)
codepath=os.getcwd()

datafilename=str(np.load(codepath+'\\prebig.npy'))[2:-2]
rawdir=codepath+'\\Raw\\' # Folder where you place the data
prodir=codepath+'\\Results\\' +datafilename+'\\'# Folder where you wish to place the processed data

data = open(rawdir+datafilename+'.txt')
seqtype =[]
# Loading the sequence information from relevant FAST files
for line in data.readlines():
    if ">" in line:
        seqtype.append(line[len(line)-2])
        
cot=0
cof=0
for p in range(len(seqtype)): 
    if seqtype[p]=='1':
        cot=cot+1
    else:
        cof=cof+1
        
binpath=prodir+'Bin\\'
modelpath=prodir+'Model\\'
metricspath=prodir+'Metrics\\'
arffpath=prodir+'Arff\\'

indbinpath=binpath+'Individual\\'
sfsbinpath=binpath+'SFS\\'
metamodpath=modelpath+'Meta\\'
finlmodpath=modelpath+'Final\\'
indarffpath=arffpath+'Individual\\'
sfsarffpath=arffpath+'SFS\\'

content=np.load(binpath+'big.npy')
names=np.load(binpath+'prebigx.npy')
logname=str(names)
data=open(logname)
rallf=[]
ravlu=[]
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Learning programme started')  
for line in data.readlines():
    fline=[]
    if len(line)<27:
        continue
    if line[27]!='f':
        continue
    for i in range(len(line)):
        if line[i]=='f' and line[i-1]==' ' :
            strn = i
        if line[i]==':' and line[i-1]==' ' :
            stpn = i
    rallf.append(line[strn+1:stpn])
    ravlu.append(line[stpn+2:stpn+8])
avlu=ravlu[0:1062]
allf=rallf[0:1062]

big=[]
big.append(content[0])
for i in range(len(allf)):
    big.append(content[int(allf[i])])
big.append(content[1063])
W1=np.transpose(big)
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Data loaded')  
def atb(x):
    atbq=[]
    atbID=('ID','REAL')
    atbq.append(atbID)
    for i in range(x):
        atbf=('f'+str(i+1),'REAL')
        atbq.append(atbf)
    atbclss=('class', ['NO', 'YES'])
    atbq.append(atbclss)
    return atbq
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   ARFF files production started')  
for i in range(1062):
    f=open(sfsarffpath+'arff'+str(1062-i)+'.arff','w')
    if i>0:
        W1=np.delete(W1,1063-i,axis=1)
    obj = {
        'description': u'',
        'relation': datafilename+'feature',
        'attributes': atb(1062-i),
        'data':W1,
    }
    f.write(arff.dumps(obj))
    f.close()
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   ARFF file production done')
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   WEKA work started')  
from weka.plot.classifiers import generate_thresholdcurve_data
from weka.plot.classifiers import get_thresholdcurve_data
Total=[]
cxx=[]
cyy=[]
for i in range(1062):
    nasavesumary='sumary'+str(i+1)
    nasavebuffer='buffer'+str(i+1)
    nasavedetail='detail'+str(i+1)
    savesumary=open(sfsbinpath+nasavesumary+'.txt','w')
    savebuffer=open(sfsbinpath+nasavebuffer+'.txt','w')
    savedetail=open(sfsbinpath+nasavedetail+'.txt','w')
    loader = Loader(classname="weka.core.converters.ArffLoader")
    data = loader.load_file(sfsarffpath+'arff'+str(i+1)+'.arff')
    data.class_is_last()

    from weka.filters import Filter
    remove = Filter(classname="weka.filters.unsupervised.attribute.Remove", options=["-R", "1"])
    cls = Classifier(classname="weka.classifiers.trees.RandomForest")

    from weka.classifiers import FilteredClassifier
    fc = FilteredClassifier()
    fc.filter = remove
    fc.classifier = cls

    fc.build_classifier(data)
    import weka.core.serialization as serialization
    classifier = fc  # previously built classifier
    serialization.write(finlmodpath +'P'+str(i+1)+'.model', classifier)

    from weka.classifiers import Evaluation
    from weka.core.classes import Random
    from weka.classifiers import PredictionOutput
    pout = PredictionOutput(classname="weka.classifiers.evaluation.output.prediction.PlainText",options=["-p","1"])
    evl = Evaluation(data)
    evl.crossvalidate_model(fc, data, 10, Random(1), pout)
    cdata=generate_thresholdcurve_data(evl,0)
    str(cdata)
    cdx,cdy= get_thresholdcurve_data(cdata, "False Positive Rate", "True Positive Rate")
    cxx.append(cdx)
    cyy.append(cdy)
    Total.append(evl.percent_correct)
    localtime = time.asctime( time.localtime(time.time()) )

    print(str(localtime)+' WEKA SFS now processing '+'NO.'+str(i+1)+' out of 1062')
    Total.append(evl.percent_correct)
    
    savesumary.writelines(evl.summary())
    savesumary.close()
    savebuffer.writelines(pout.buffer_content())
    savebuffer.close()
    savedetail.writelines(evl.class_details())
    savedetail.close()
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   WEKA work done')

jvm.stop()
def savetu(W1,ad):
    datasave = openpyxl.Workbook()  
    datasave.create_sheet('Sheet1') 
    table = datasave.active
    index=len(W1)
    for j in range(index):
        each = W1[j]
        for k in range(len(each)):
            table.cell(k+1, j+1, each[k])
    datasave.save(sfsbinpath+ad)
    datasave.close()# 保存工作簿

savetu(cxx,datafilename+'FP.xls')
savetu(cyy,datafilename+'TP.xls')

localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   WEKA SFS done')
def readSP(x):
    data=open(x)
    for line in data.readlines():
        if line[96:97]=='O':
            ppp=line[17:24]      
    return ppp

def readSE(x):
    data=open(x)
    for line in data.readlines():
        if line[96:97]=='E':
            ppp=line[17:24]      
    return ppp

def readMCC(x):
    data=open(x)
    for line in data.readlines():
        if line[0]=='W':
            ppp=line[66:71]      
    return ppp

def readAUC(x):
    data=open(x)
    for line in data.readlines():
        if line[0]=='W':
            ppp=line[75:80]      
    return ppp
localtime = time.asctime( time.localtime(time.time()) )
print(str(localtime)+'   Records production started')  
lrmetrics=metricspath
merics=[]
listAUC=[]
for i in range(1062):
    mericline=[]
    mericfile=sfsbinpath+'detail'+str(i+1)+'.txt'
    AUC=readAUC(mericfile)
    listAUC.append(readAUC(mericfile))
    MCC=readMCC(mericfile)
    SE=float(readSE(mericfile))
    SP=float(readSP(mericfile))
    TP=round(cof*SE)
    TN=round(cot*SP)
    FP=cot-TN
    FN=cof-TP
    mericline.append(AUC)
    mericline.append(MCC)
    mericline.append(str(SE))
    mericline.append(str(SP))
    mericline.append(str(TP))
    mericline.append(str(TN))
    mericline.append(str(FP))
    mericline.append(str(FN))
    merics.append(mericline)

maxaucvalue=listAUC[0]
maxid=0
for i in range(len(listAUC)):
    if listAUC[i]>maxaucvalue:
        maxaucvalue= listAUC[i]
        maxid=i
        
maxid=maxid+1           
index = len(merics)  
workbook = xlwt.Workbook()  
sheet = workbook.add_sheet('sheet_name') 
linehead=['No.','AUC','ACC','MCC','SE','SP','TP','TN','FP','FN']
for j in range(0, len(linehead)):
    sheet.write(0, j, linehead[j])
for i in range(0, index):
    wrtmericline=merics[i]
    sheet.write(i+1,0,i+1)
    sheet.write(i+1,1,wrtmericline[0])
    sheet.write(i+1,3,wrtmericline[1])
    sheet.write(i+1,4,wrtmericline[2])
    sheet.write(i+1,5,wrtmericline[3])
    sheet.write(i+1,6,wrtmericline[4])
    sheet.write(i+1,7,wrtmericline[5])
    sheet.write(i+1,8,wrtmericline[6])
    sheet.write(i+1,9,wrtmericline[7])
    sheet.write(i+1,2,Total[i]/100) 
filename = 'Metrics_SFS'+'.xls'
workbook.save(lrmetrics +filename) 

selectedp=allf[0:maxid]
index = len(selectedp) 
workbook = xlwt.Workbook()  
sheet = workbook.add_sheet('sheet_name')  
linehead=['No.']
for j in range(0, len(linehead)):
    sheet.write(0, j, linehead[j])
for i in range(0, index):
    sheet.write(i+1,0,selectedp[i])   
filename = 'Selected properties'+datafilename+'.xls'
workbook.save(sfsbinpath +filename) 
localtime = time.asctime( time.localtime(time.time()) )

meta1=metricspath+'Metrics_meta.xls'
meta2=metricspath+'Metrics_meta_full.xls'

def getcol(x):
    col = pd.read_excel(meta1, usecols=[x])
    col_list = col.values.tolist()
    result = []
    for col_listx in col_list:
        result.append(col_listx[0])
    return result

col1=getcol(0)
col2=getcol(1)
col3=getcol(2)
col4=getcol(3)
col5=getcol(4)
col6=getcol(5)
col7=getcol(6)
col8=getcol(7)
col9=getcol(8)
col10=getcol(9)
col11=getcol(10)
col12=getcol(12)

index = len(col12)
workbook = xlwt.Workbook()  
sheet = workbook.add_sheet('sheet_name')
linehead=['No.','ID','AUC','ACC','MCC','SE','SP','TP','TN','FP','FN','cls MRMD score','prb MRMD score','Description']
for j in range(0, len(linehead)):
    sheet.write(0, j, linehead[j])
for i in range(0, index):
    sheet.write(i+1,0,col1[i])
    sheet.write(i+1,1,col2[i])
    sheet.write(i+1,2,col3[i])
    sheet.write(i+1,3,col4[i])
    sheet.write(i+1,4,col5[i])
    sheet.write(i+1,5,col6[i])
    sheet.write(i+1,6,col7[i]) 
    sheet.write(i+1,7,col8[i])
    sheet.write(i+1,8,col9[i])
    sheet.write(i+1,9,col10[i])
    sheet.write(i+1,10,col11[i])
    sheet.write(i+1,13,col12[i])   
for i in range(0,1062):
    if int(allf[i])>531:
        sheet.write(int(allf[i])-531,11,avlu[i])
    if int(allf[i])<=531:
        sheet.write(int(allf[i]),12,avlu[i])
workbook.save(meta2)  
os.remove(meta1)
print(str(localtime)+'   Records production done')  
print('best AUC: '+maxaucvalue)
print('No. of dimensions: '+str(maxid))
print("If you want to perform independent test, please run TEST.py with parametres confirmed")
    
